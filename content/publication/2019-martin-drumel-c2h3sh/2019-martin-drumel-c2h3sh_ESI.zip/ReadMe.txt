J/A+A/623/A167   C2H3SH observed experimental transitions (Martin-Drumel+, 2019)
================================================================================
Submillimeter spectroscopy and astronomical searches of vinyl mercaptan,
C_2_H_3_SH.
    Martin-Drumel M.-A., Lee K.L.K., Belloche A., Zingsheim O., Thorwirth S.,
    Mueller H.S.P., Lewen F., Garrod R.T., Menten K.M., McCarthy M.C.,
    Schlemmer S.
    <Astron. Astrophys. 623, A167 (2019)>
    =2019A&A...623A.167M        (SIMBAD/NED BibCode)
================================================================================
ADC_Keywords: Atomic physics ; Interstellar medium
Keywords: astrochemistry - molecular data - method: laboratory: molecular -
          ISM: individual objects: Sagittarius B2 (N) - ISM: molecules -
          surveys

Abstract:
    New laboratory investigations of the rotational spectrum of postulated
    astronomical species are essential to support the assignment and
    analysis of current astronomical surveys. In particular, considerable
    interest surrounds sulfur analogs of oxygen-containing interstellar
    molecules and their isomers.

    To enable reliable interstellar searches of vinyl mercaptan, the
    sulfur-containing analog to the astronomical species vinyl alcohol, we
    investigated its pure rotational spectrum at millimeter wavelengths.
    We extended the pure rotational investigation of the two isomers syn
    and anti vinyl mercaptan to the millimeter domain using a
    frequency-multiplication spectrometer. The species were produced by a
    radiofrequency discharge in 1,2-ethanedithiol. Additional transitions
    were remeasured in the centimeter band using Fourier-transform
    microwave spectroscopy to better determine rest frequencies of
    transitions with low-J and low-Ka values. Experimental investigations
    were supported by quantum chemical calculations on the energetics of
    both the [C_2_,H_4_,S] and [C_2_,H_4_,O] isomeric families.
    Interstellar searches for both syn and anti vinyl mercaptan as well as
    vinyl alcohol were performed in the EMoCA spectral line survey carried
    out toward Sgr B2(N2) with ALMA. Results. Highly accurate experimental
    frequencies (to better than 100kHz accuracy) for both syn and anti
    isomers of vinyl mercaptan are measured up to 250GHz; these deviate
    considerably from predictions based on extrapolation of previous
    microwave measurements. Reliable frequency predictions of the
    astronomically most interesting millimeter-wave lines for these two
    species can now be derived from the best-fit spectroscopic constants.
    From the energetic investigations, the four lowest singlet isomers of
    the [C2,H4,S] family are calculated to be nearly isoenergetic, which
    makes this family a fairly unique test bed for assessing possible
    reaction pathways. Upper limits for the column density of syn and anti
    vinyl mercaptan are derived toward the extremely molecule-rich
    star-forming region Sgr B2(N2) enabling comparison with selected
    complex organic molecules.

Description:
    The tables constain the list of measured transitions of both syn- and
    anti-vinyl mercaptan. Frequencies are given in MHz. Values in
    parentheses represent 1sigma uncertainty. The obs.-calc. values are
    given in kHz.

File Summary:
--------------------------------------------------------------------------------
 FileName   Lrecl  Records  Explanations
--------------------------------------------------------------------------------
ReadMe         80        .  This file
tableb1.dat    41      296  Observed experimental transitions of vinyl mercaptan
tableb2.dat    41      173  Observed frequencies for anti-vinyl mercaptan
--------------------------------------------------------------------------------

Byte-by-byte Description of file: tableb1.dat tableb2.dat
--------------------------------------------------------------------------------
   Bytes Format Units     Label   Explanations
--------------------------------------------------------------------------------
   1-  2  I2    ---       J'      Lower J quantum number
   4-  5  I2    ---       Ka'     Lower Ka quantum number
   7-  8  I2    ---       Kc'     Lower Kc quantum number
  10- 11  I2    ---       J"      Upper J quantum number
  13- 14  I2    ---       Ka"     Upper Ka quantum number
  16- 17  I2    ---       Kc"     Upper Kc quantum number
  19- 29  F11.4 MHz       Obs     Observed transition frequency
  31- 34  I4    10-4MHz e_Obs     1{sigma} error on Obs
  36- 41  F6.1  MHz       O-C     Observed minus calculated frequencies
--------------------------------------------------------------------------------

Acknowledgements:
    Marie-Aline Martin-Drumel, marie-aline.martin(at)u-psud.fr

================================================================================
(End)                                        Patricia Vannier [CDS]  28-Feb-2019
